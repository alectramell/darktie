# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014 Alec Tramell, DMA alectramell@gmail.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import os

from locale import gettext as _

from gi.repository import Gtk, WebKit # pylint: disable=E0611
import logging
logger = logging.getLogger('lemonade')

from lemonade_lib import Window
from lemonade.AboutLemonadeDialog import AboutLemonadeDialog
from lemonade.PreferencesLemonadeDialog import PreferencesLemonadeDialog

# See lemonade_lib.Window.py for more details about how this class works
class LemonadeWindow(Window):
    __gtype_name__ = "LemonadeWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(LemonadeWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutLemonadeDialog
        self.PreferencesDialog = PreferencesLemonadeDialog

        # Code for other initialization actions should be added here.

        self.scrolledwindow1 = self.builder.get_object('scrolledwindow1')
        self.editbutton = self.builder.get_object('editbutton')
        self.exitbutton = self.builder.get_object('exitbutton')
        self.refreshbutton = self.builder.get_object('refreshbutton')
        self.folderbutton = self.builder.get_object('folderbutton')
        self.advancedbutton = self.builder.get_object('advancedbutton')
        self.lemonbutton = self.builder.get_object('lemonbutton')

        self.webview = WebKit.WebView()

        self.scrolledwindow1.add(self.webview)
        self.webview.show()

        home = str('/usr/share/lemonade/media/project/index.html')
        self.webview.open(home)

    def on_exitbutton_clicked(self, wigdet):
        exit()

    def on_editbutton_clicked(self, widget):
        os.system('clear')
        os.system('XPASS=$(zenity --password --title="Lemonade v1.0 (EDIT)") && echo "$XPASS" | sudo -S gedit --wait /usr/share/lemonade/media/project/index.html &')
        os.system('clear')

    def on_refreshbutton_clicked(self, widget):
        home = str('/usr/share/lemonade/media/project/index.html')
        self.webview.open(home)

    def on_folderbutton_clicked(self, widget):
        os.system('clear')
        os.system('XPASS=$(zenity --password --title="Lemonade v1.0 (ITEMS)") && echo "$XPASS" | sudo -S gnome-open /usr/share/lemonade/media/project/ &')

    def on_advancedbutton_clicked(self, widget):
        os.system('clear')
        os.system('XPASS=$(zenity --password --title="Lemonade v1.0 (SNOWSTORM)") && echo "$XPASS" | sudo -S gedit --wait /usr/share/lemonade/media/project/snowstorm.js &')
        os.system('clear')

    def on_lemonbutton_clicked(self, widget):
        os.system('clear')
        os.system('mkdir ~/Desktop/lemonade-save')
        os.system('XPASS=$(zenity --password --title="Lemonade v1.0 (SAVE)") && echo "$XPASS" | gnome-terminal --title="Lemonade v1.0 | Saving.." -x sh -c "cp -r /usr/share/lemonade/media/project/ ~/Desktop/lemonade-save" &')
        os.system('gnome-open ~/Desktop/lemonade-save/project/')
        os.system('clear')





