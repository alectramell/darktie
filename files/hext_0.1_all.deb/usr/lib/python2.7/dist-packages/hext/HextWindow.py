# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014 Alec Tramell, DMA alectramell@gmail.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import os
import platform

from locale import gettext as _

from gi.repository import Gtk # pylint: disable=E0611
import logging
logger = logging.getLogger('hext')

from hext_lib import Window
from hext.AboutHextDialog import AboutHextDialog
from hext.PreferencesHextDialog import PreferencesHextDialog

# See hext_lib.Window.py for more details about how this class works
class HextWindow(Window):
    __gtype_name__ = "HextWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(HextWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutHextDialog
        self.PreferencesDialog = PreferencesHextDialog

        # Code for other initialization actions should be added here.

	    self.label1 = self.builder.get_object("label1")
	    self.entry1 = self.builder.get_object("entry1")
        
        self.label1.set_label('[HEX CODE..]')

    def on_entry1_activate(self, widget):
        x = widget.get_text()
        x = x.encode('hex')
        x = str(x)
        self.label1.set_label('HEX = ' + x)
        os.system('touch ~/Desktop/hexout.txt && echo "' + x + '" > ~/Desktop/hexout.txt')
        os.system('clear')






