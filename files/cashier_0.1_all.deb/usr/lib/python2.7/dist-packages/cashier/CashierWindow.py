# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014 Alec Tramell, DMA alectramell@gmail.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import os
import getpass
import datetime
import decimal

from locale import gettext as _

from gi.repository import Gtk # pylint: disable=E0611
import logging
logger = logging.getLogger('cashier')

from cashier_lib import Window
from cashier.AboutCashierDialog import AboutCashierDialog
from cashier.PreferencesCashierDialog import PreferencesCashierDialog

# See cashier_lib.Window.py for more details about how this class works
class CashierWindow(Window):
    __gtype_name__ = "CashierWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(CashierWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutCashierDialog
        self.PreferencesDialog = PreferencesCashierDialog

        # Code for other initialization actions should be added here.

        self.addbutton = self.builder.get_object('addbutton')
        self.calcbutton = self.builder.get_object('calcbutton')
        self.indexbutton = self.builder.get_object('indexbutton')
        self.exitbutton = self.builder.get_object('exitbutton')
        self.label1 = self.builder.get_object('label1')
        self.label2 = self.builder.get_object('label2')
        self.entry1 = self.builder.get_object('entry1')
        self.entry2 = self.builder.get_object('entry2')

        self.user = str(getpass.getuser())

        me = str(self.user)

        os.system('touch /home/' + me + '/cashier/amounts.txt')

        bank = open('/home/' + me + '/cashier/amounts.txt','r')
        self.totals = bank.read()
        bank.close()
        self.totals = str(self.totals)

        today = datetime.date.today()
        date = str(today)

        self.label2.set_label('Todays Date: ' + date)

        self.label1.set_label('$0.00')

    def on_entry1_activate(self, widget):
        os.system('mkdir ~/cashier/')
        amounts = self.entry1.get_text()
        amounts = decimal.Decimal(amounts)
        charge = self.entry2.get_text()
        charge = decimal.Decimal(charge)
        amounts = (amounts - charge)
        amounts = str(amounts)
        charge = str(charge)
        os.system('DAY=$(date -I) && echo "$DAY: +' + charge + '" >> ~/cashier/amounts.txt')
        self.label1.set_label('Change: $' + amounts)

    def on_entry2_activate(self, widget):
        os.system('sudo mkdir ~/cashier/')
        amounts = self.entry1.get_text()
        amounts = decimal.Decimal(amounts)
        charge = self.entry2.get_text()
        charge = decimal.Decimal(charge)
        amounts = (amounts - charge)
        amounts = str(amounts)
        charge = str(charge)
        os.system('DAY=$(date -I) && echo "$DAY: +' + charge + '" >> ~/cashier/amounts.txt')
        self.label1.set_label('Change: $' + amounts)

    def on_addbutton_clicked(self, widget):
        os.system('mkdir ~/cashier/')
        amounts = self.entry1.get_text()
        amounts = decimal.Decimal(amounts)
        charge = self.entry2.get_text()
        charge = decimal.Decimal(charge)
        amounts = (amounts - charge)
        amounts = str(amounts)
        charge = str(charge)
        os.system('DAY=$(date -I) && echo "$DAY: +' + charge + '" >> ~/cashier/amounts.txt')
        self.label1.set_label('Change: $' + amounts)

    def on_indexbutton_clicked(self, widget):
        os.system('clear')
        os.system('gnome-open ~/cashier/amounts.txt')

    def on_calcbutton_clicked(self, widget):
        os.system('clear')
        os.system('gnome-calculator')

    def on_exitbutton_clicked(self, widget):
        os.system('clear')
        me = str(self.user)
        os.system('DAY=$(date -I) && sudo cp /home/' + me + '/cashier/amounts.txt ~/Desktop/sales-log.txt && gnome-open ~/Desktop/sales-log.txt')
        os.system('clear')
        exit()














