# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014 Alec Tramell, DMA alectramell@gmail.com
# 
# Kink Radio
# http://www.kink.fm/
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import os

from locale import gettext as _

from gi.repository import Gtk, WebKit # pylint: disable=E0611
import logging
logger = logging.getLogger('kink')

from kink_lib import Window
from kink.AboutKinkDialog import AboutKinkDialog
from kink.PreferencesKinkDialog import PreferencesKinkDialog

# See kink_lib.Window.py for more details about how this class works
class KinkWindow(Window):
    __gtype_name__ = "KinkWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(KinkWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutKinkDialog
        self.PreferencesDialog = PreferencesKinkDialog

        # Code for other initialization actions should be added here.

        self.refreshbutton = self.builder.get_object('refreshbutton')
        self.outbutton = self.builder.get_object('outbutton')
        self.exitbutton = self.builder.get_object('exitbutton')
        self.flashbutton = self.builder.get_object('flashbutton')
        self.scrolledwindow1 = self.builder.get_object('scrolledwindow1')

        self.webview = WebKit.WebView()

        self.scrolledwindow1.add(self.webview)
        self.webview.show()

        home = str('http://player.streamtheworld.com/liveplayer.php?callsign=KINKFM')
        self.webview.open(home)

    def on_refreshbutton_clicked(self, widget):
        home = str('http://player.streamtheworld.com/liveplayer.php?callsign=KINKFM')
        self.webview.open(home)

    def on_outbutton_clicked(self, widget):
        gourl = str('sensible-browser --new-window=http://tunein.com/radio/KINK-1019-s33175/ &')
        os.system(gourl)

    def on_exitbutton_clicked(self, widget):
        os.system('killall kink')
        exit()

    def on_flashbutton_clicked(self, widget):
        updates = str('''
gnome-terminal --title="KINK | Activate Flash Player.." -x sh -c "sudo apt-get install flashplugin-installer && sudo apt-get install nspluginwrapper && sudo nspluginwrapper -i /usr/lib/flashplugin-installer/libflashplayer.so && nspluginwrapper -v -a -n -i &"
''')
        os.system(updates)






