#!/usr/bin/python

from distutils.core import setup

setup(name='skp',
      version='1.0',
      py_modules=['skp']
      )
