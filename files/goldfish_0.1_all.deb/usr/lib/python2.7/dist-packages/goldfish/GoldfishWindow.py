# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014 Alec Tramell alectramell@gmail.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import os

from locale import gettext as _

from gi.repository import Gtk # pylint: disable=E0611
import logging
logger = logging.getLogger('goldfish')

from goldfish_lib import Window
from goldfish.AboutGoldfishDialog import AboutGoldfishDialog
from goldfish.PreferencesGoldfishDialog import PreferencesGoldfishDialog

# See goldfish_lib.Window.py for more details about how this class works
class GoldfishWindow(Window):
    __gtype_name__ = "GoldfishWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(GoldfishWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutGoldfishDialog
        self.PreferencesDialog = PreferencesGoldfishDialog

        # Code for other initialization actions should be added here.

        self.zipbutton = self.builder.get_object('zipbutton')
        self.unzipbutton = self.builder.get_object('unzipbutton')
        self.folderbutton = self.builder.get_object('folderbutton')
        self.exitbutton = self.builder.get_object('exitbutton')
        self.flushbutton = self.builder.get_object('flushbutton')

        os.system('mkdir ~/goldfish')
        os.system('mkdir ~/goldfish/fishbowl')

    def on_zipbutton_clicked(self, widget):
        os.system('cd ~/ && INFILE=$(zenity --file-selection --title="Add File..") && gnome-terminal --title="Compressing file into fish.." -x sh -c "zip ~/goldfish/.fish.zip $INFILE"')
        os.system('zenity --info --title="Goldfish v1.0" --text="Fish Created!"')

    def on_unzipbutton_clicked(self, widget):
        os.system('cd ~/goldfish/ && gnome-terminal --title="Updating Fishbowl.." -x sh -c "unzip -j -o ~/goldfish/.fish.zip -d ~/goldfish/fishbowl/"')
        os.system('zenity --info --title="Goldfish v1.0" --text="Update Complete!"')
        os.system('gnome-open ~/goldfish/fishbowl/')

    def on_folderbutton_clicked(self, widget):
        os.system('gnome-open ~/goldfish/fishbowl/')

    def on_exitbutton_clicked(self, widget):
        os.system('clear')
        exit()

    def on_flushbutton_clicked(self, widget):
        os.system('clear')
        os.system('gnome-terminal --title="Empty Fishbowl.." -x sh -c "sudo -S rm ~/goldfish/.fish.zip"')
        os.system('rm ~/goldfish/fishbowl/*')
        os.system('zenity --info --title="Goldfish v1.0" --text="Flush Complete!"')
        os.system('clear')








