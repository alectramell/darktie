# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014 Alec Tramell, DMA alectramell@gmail.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import os
import random
import getpass

from locale import gettext as _

from gi.repository import Gtk, WebKit # pylint: disable=E0611
import logging
logger = logging.getLogger('olympus')

from olympus_lib import Window
from olympus.AboutOlympusDialog import AboutOlympusDialog
from olympus.PreferencesOlympusDialog import PreferencesOlympusDialog

# See olympus_lib.Window.py for more details about how this class works
class OlympusWindow(Window):
    __gtype_name__ = "OlympusWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(OlympusWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutOlympusDialog
        self.PreferencesDialog = PreferencesOlympusDialog

        # Code for other initialization actions should be added here.

        self.refreshbutton = self.builder.get_object('refreshbutton')
        self.entry1 = self.builder.get_object('entry1')
        self.entry2 = self.builder.get_object('entry2')
        self.scrolledwindow1 = self.builder.get_object('scrolledwindow1')
        self.exitbutton = self.builder.get_object('exitbutton')
        self.homebutton = self.builder.get_object('homebutton')
        self.webleafbutton = self.builder.get_object('webleafbutton')
        self.firefoxbutton = self.builder.get_object('firefoxbutton')
        self.loadbutton = self.builder.get_object('loadbutton')
        self.status = self.builder.get_object('status')
        self.backbutton = self.builder.get_object('backbutton')
        self.forwardbutton = self.builder.get_object('forwardbutton')
        self.colorbutton = self.builder.get_object('colorbutton')
        self.googlebutton = self.builder.get_object('googlebutton')

        self.user = str(getpass.getuser())

        self.webview = WebKit.WebView()

        self.scrolledwindow1.add(self.webview)
        self.webview.show()

        home = random.choice(['http://www.facebook.com/apollondma','http://apps.ubuntu.com','http://www.ubuntu.com','http://www.google.com'])
        home = str(home)
        self.status.set_label(home)
        self.webview.open(home)

    def on_olympusbutton_clicked(self, widget):
        os.system('clear')
        project = str('file:///home/' + self.user + '/mysite/index.html')
        self.status.set_label('This is your Website!')
        self.webview.open(project)

    def on_webleafbutton_clicked(self, widget):
        os.system('clear')
        os.system('cd ~/Downloads && WEBLEAF=$(zenity --entry --title="WebLeaf v1.0" --text="File URL:") && cd ~/Downloads/ && wget $WEBLEAF && gnome-open ~/Downloads/')

    def on_homebutton_clicked(self, widget):
        os.system('clear')
        home = str('http://www.facebook.com/apollondma')
        self.status.set_label(home)
        self.webview.open(home)

    def on_refreshbutton_clicked(self, widget):
        os.system('clear')
        self.status.set_label('..Refresh..')
        self.webview.reload()

    def on_entry1_activate(self, widget):
        os.system('clear')
        url = widget.get_text()
        url = str('http://' + url)
        self.status.set_label(url)
        self.webview.open(url)

    def on_entry2_activate(self, widget):
        os.system('clear')
        search = widget.get_text()
        self.status.set_label('Google Search for "' + search + '"..')
        searchem = str('https://www.google.com/?gws_rd=ssl#q=' + search)
        self.webview.open(searchem)

    def on_googlebutton_clicked(self, widget):
        os.system('clear')
        search = self.entry2.get_text()
        self.status.set_label('Google Search for "' + search + '"..')
        searchem = str('https://www.google.com/?gws_rd=ssl#q=' + search)
        self.webview.open(searchem)

    def on_backbutton_clicked(self, widget):
        os.system('clear')
        self.status.set_label('Back..')
        self.webview.go_back()

    def on_forwardbutton_clicked(self, widget):
        os.system('clear')
        self.status.set_label('..Forward')
        self.webview.go_forward()

    def on_exitbutton_clicked(self, widget):
        os.system('clear')
        exit()

    def on_firefoxbutton_clicked(self, widget):
        os.system('clear')
        os.system('firefox --new-window="file:///home/' + self.user + '/mysite/index.html"')

    def on_loadbutton_clicked(self, widget):
        os.system('clear')
        os.system('mkdir ~/mysite/')
        os.system('mkdir ~/mysite/images/')
        os.system('touch ~/mysite/index.html')
        os.system('touch ~/mysite/README.md')
        os.system('echo "Edit the index.html file within ~/mysite/ directory! Have Fun!" > ~/mysite/README.md')
        self.status.set_label('Edit your Website!')
        os.system('gnome-open ~/mysite/')
        self.webview.open('file:///home/' + self.user + '/mysite/index.html')

    def on_colorbutton_clicked(self, widget):
        os.system('clear')
        os.system('zenity --color-selection')
        




