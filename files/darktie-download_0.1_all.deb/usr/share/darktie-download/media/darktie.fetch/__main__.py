#!/usr/bin/python

import os

os.system('clear')

os.system('XPASS=$(zenity --password --title="User (Authenticate!)") && echo "$XPASS" | sudo -S rm -r ~/.darktie && cd ~ && echo "$XPASS" | sudo -S git clone http://github.com/alectramell/darktie.git && echo "$XPASS" | sudo mv ~/darktie ~/.darktie && echo "$XPASS" | sudo -S gnome-open ~/.darktie/files')

os.system('clear')


