# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014 Alec Tramell, DMA alectramell@gmail.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import os

from locale import gettext as _

from gi.repository import Gtk # pylint: disable=E0611
import logging
logger = logging.getLogger('darktie_download')

from darktie_download_lib import Window
from darktie_download.AboutDarktieDownloadDialog import AboutDarktieDownloadDialog
from darktie_download.PreferencesDarktieDownloadDialog import PreferencesDarktieDownloadDialog

# See darktie_download_lib.Window.py for more details about how this class works
class DarktieDownloadWindow(Window):
    __gtype_name__ = "DarktieDownloadWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(DarktieDownloadWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutDarktieDownloadDialog
        self.PreferencesDialog = PreferencesDarktieDownloadDialog

        # Code for other initialization actions should be added here.

        self.updatebutton = self.builder.get_object('updatebutton')
        self.exitbutton = self.builder.get_object('exitbutton')
        self.helpbutton = self.builder.get_object('helpbutton')
        self.facebutton = self.builder.get_object('facebutton')
        self.folderbutton = self.builder.get_object('folderbutton')
        self.pybutton = self.builder.get_object('pybutton')
        self.label1 = self.builder.get_object('label1')
        self.title = self.builder.get_object('title')

        self.title.set_label('DARKTIE v1.0')
        self.label1.set_label('Apollon Data Metrics | Software Dropbox')

    def on_exitbutton_clicked(self, widget):
        os.system('clear')
        exit()

    def on_updatebutton_clicked(self, widget):
        self.title.set_label('Updates')
        os.system('gnome-terminal --title="Darktie Package Update.." -x sh -c "python /usr/share/darktie-download/media/darktie.fetch" && zenity --info --title="Darktie v1.0" --text="Package Update Complete!" &')
        self.label1.set_label('..Update Darktie Packages..')

    def on_facebutton_clicked(self, widget):
        self.title.set_label('Apollon Data Metrics')
        self.label1.set_label('http://www.facebook.com/apollondma')
        os.system('sensible-browser --new-window="http://www.facebook.com/apollondma" &')

    def on_folderbutton_clicked(self, widget):
        os.system('clear')
        self.title.set_label('App Debian Files')
        self.label1.set_label('..Install available packages..')
        os.system('cd ~/.darktie/files/ && PKG=$(zenity --file-selection --title="Install Package..") && gnome-terminal --title="Install Package (AUTHENTICATION)" -x sh -c "sudo dpkg -i $PKG" && zenity --info --title="Software Package.." --text="Installation Complete!" &')

    def on_helpbutton_clicked(self, widget):
        self.title.set_label('Need Information?')
        self.label1.set_label('..message us on Facebook..')
        os.system('sensible-browser --new-window="https://m.facebook.com/messages/thread/215380691966805/?refid=9&refsrc=https%3A%2F%2Fm.facebook.com%2Fapollondma&_rdr#_=_" &')
        os.system('clear')

    def on_pybutton_clicked(self, widget):
        os.system('clear')
        self.title.set_label('Python Modules')
        self.label1.set_label('..Install available modules..')
        os.system('cd ~/.darktie/pymods/ && PKG=$(zenity --file-selection --title="Install Python Module.." --directory) && gnome-terminal --title="Install Python Module (AUTHENTICATION)" -x sh -c "sudo pip install -e $PKG" && zenity --info --title="Python Module.." --text="Installation Complete!" &')
        


