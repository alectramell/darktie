# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014 Alec Tramell, DMA alectramell@gmail.com
# 
# This app works in conjuntion with but is not managed by Facebook (www.facebook.com), this soaftware works in agreement between Apollon Data Metrics (ADM) and Facebook (www.facebook.com).
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import os

from locale import gettext as _

from gi.repository import Gtk, WebKit # pylint: disable=E0611
import logging
logger = logging.getLogger('adm_facebook')

from adm_facebook_lib import Window
from adm_facebook.AboutAdmFacebookDialog import AboutAdmFacebookDialog
from adm_facebook.PreferencesAdmFacebookDialog import PreferencesAdmFacebookDialog

# See adm_facebook_lib.Window.py for more details about how this class works
class AdmFacebookWindow(Window):
    __gtype_name__ = "AdmFacebookWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(AdmFacebookWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutAdmFacebookDialog
        self.PreferencesDialog = PreferencesAdmFacebookDialog

        # Code for other initialization actions should be added here.

        self.homebutton = self.builder.get_object("homebutton")
        self.msgbutton = self.builder.get_object("msgbutton")
        self.admbutton = self.builder.get_object("admbutton")
        self.exitbutton = self.builder.get_object("exitbutton")
        self.scrolledwindow1 = self.builder.get_object("scrolledwindow1")

        self.webview = WebKit.WebView()

        self.scrolledwindow1.add(self.webview)
        self.webview.show()

        self.webview.open('https://m.facebook.com')

    def on_homebutton_clicked(self, widget):
        os.system('clear')
        self.webview.open('https://m.facebook.com')

    def on_msgbutton_clicked(self, widget):
        os.system('clear')
        self.webview.open('https://m.facebook.com/buddylist.php?ref_component=mbasic_home_header&ref_page=%2Fwap%2Fhome.php&refid=7')

    def on_admbutton_clicked(self, widget):
        os.system('clear')
        self.webview.open('https://m.facebook.com/apollondma')

    def on_exitbutton_clicked(self, widget):
        os.system('clear')
        exit()    



