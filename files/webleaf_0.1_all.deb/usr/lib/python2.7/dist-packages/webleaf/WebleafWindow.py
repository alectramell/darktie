# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014 Alec Tramell, DMA alectramell@gmail.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import os

from locale import gettext as _

from gi.repository import Gtk # pylint: disable=E0611
import logging
logger = logging.getLogger('webleaf')

from webleaf_lib import Window
from webleaf.AboutWebleafDialog import AboutWebleafDialog
from webleaf.PreferencesWebleafDialog import PreferencesWebleafDialog

# See webleaf_lib.Window.py for more details about how this class works
class WebleafWindow(Window):
    __gtype_name__ = "WebleafWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(WebleafWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutWebleafDialog
        self.PreferencesDialog = PreferencesWebleafDialog

        # Code for other initialization actions should be added here.

        self.newbutton = self.builder.get_object("newbutton")
        self.folderbutton = self.builder.get_object("folderbutton")
        self.exitbutton = self.builder.get_object("exitbutton")
        self.entry = self.builder.get_object("entry")

    def on_entry_activate(self, widget):
        os.system('clear')
        fileurl = widget.get_text()
        fileurl = str(fileurl)
        os.system('cd ~/Downloads && gnome-terminal --title="Webleaf | File Download.." -x sh -c "wget ' + fileurl + '" && zenity --info --title="Webleaf" --text="File Download Complete!"')
        os.system('gnome-open ~/Downloads/')
    
    def on_newbutton_clicked(self, widget):
        os.system('clear')
        fileurl = self.entry.get_text()
        fileurl = str(fileurl)
        os.system('cd ~/Downloads && gnome-terminal --title="Webleaf | File Download.." -x sh -c "wget ' + fileurl + '" && zenity --info --title="Webleaf" --text="File Download Complete!"')
        os.system('gnome-open ~/Downloads/')

    def on_folderbutton_clicked(self, widget):
        os.system('clear')
        os.system('gnome-open ~/Downloads/')


    def on_exitbutton_clicked(self, widget):
        exit()






