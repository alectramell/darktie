# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014 Alec Tramell, DMA alectramell@gmail.com
# 
# Affiliations:
# 
# PayPal Inc. http://www.paypal.com
# 
# Canonical Group. http://www.canonical.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import os
import getpass

from locale import gettext as _

from gi.repository import Gtk, WebKit # pylint: disable=E0611
import logging
logger = logging.getLogger('ucode')

from ucode_lib import Window
from ucode.AboutUcodeDialog import AboutUcodeDialog
from ucode.PreferencesUcodeDialog import PreferencesUcodeDialog

# See ucode_lib.Window.py for more details about how this class works
class UcodeWindow(Window):
    __gtype_name__ = "UcodeWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(UcodeWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutUcodeDialog
        self.PreferencesDialog = PreferencesUcodeDialog

        # Code for other initialization actions should be added here.

        self.exitbutton = self.builder.get_object('exitbutton')
        self.homebutton = self.builder.get_object('homebutton')
        self.scrolledwindow1 = self.builder.get_object('scrolledwindow1')
        self.paypalbutton = self.builder.get_object('paypalbutton')
        self.pythonbutton = self.builder.get_object('pythonbutton')
        self.appsbutton = self.builder.get_object('appsbutton')
        self.label1 = self.builder.get_object('label1')

        self.webview = WebKit.WebView()

        self.scrolledwindow1.add(self.webview)
        self.webview.show()

        login = str('https://myapps.developer.ubuntu.com/dev/apps/')
        self.webview.open(login)

        username = getpass.getuser()
        username = str(username)
        name = str(username)
        self.label1.set_label(name)

    def on_exitbutton_clicked(self, widget):
        os.system('clear')
        exit()

    def on_homebutton_clicked(self, widget):
        self.webview.open('https://myapps.developer.ubuntu.com/dev/apps/')
        os.system('clear')

    def on_pythonbutton_clicked(self, widget):
        self.webview.open('https://docs.python.org/devguide/')
        os.system('clear')

    def on_paypalbutton_clicked(self, widget):
        self.webview.open('https://www.paypal.com/signin/?returnUrl=%2Fcgi-bin%2Fwebscr%3Fcmd%3D_account&country.x=US&locale.x=en_US')
        os.system('clear')

    def on_appsbutton_clicked(self, widget):
        os.system('software-center &')
        os.system('clear')









