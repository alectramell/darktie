# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# This file is in the public domain
### END LICENSE

import os
import getpass

from locale import gettext as _

from gi.repository import Gtk, WebKit # pylint: disable=E0611
import logging
logger = logging.getLogger('prey')

from prey_lib import Window
from prey.AboutPreyDialog import AboutPreyDialog
from prey.PreferencesPreyDialog import PreferencesPreyDialog

# See prey_lib.Window.py for more details about how this class works
class PreyWindow(Window):
    __gtype_name__ = "PreyWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(PreyWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutPreyDialog
        self.PreferencesDialog = PreferencesPreyDialog

        # Code for other initialization actions should be added here.

        self.scrolledwindow1 = self.builder.get_object('scrolledwindow1')
        self.preybutton = self.builder.get_object('preybutton')
        self.exitbutton = self.builder.get_object('exitbutton')

        username = getpass.getuser()
        username = str(username)

        self.webview = WebKit.WebView()

        self.scrolledwindow1.add(self.webview)
        self.webview.show()

        home = str('https://panel.preyproject.com/login')
        self.webview.open(home)

    def on_exitbutton_clicked(self, widget):
        os.system('clear')
        exit()

    def on_preybutton_clicked(self, widget):
        os.system('clear')
        home = str('https://panel.preyproject.com/login')
        self.webview.open(home)

