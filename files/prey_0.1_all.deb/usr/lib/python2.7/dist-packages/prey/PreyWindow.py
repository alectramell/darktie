# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014 Alec Tramell, DMA alectramell@gmail.com
# 
# Affiliates..
# 
# Prey Project
# http://www.preyproject.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import os
import getpass

from locale import gettext as _

from gi.repository import Gtk # pylint: disable=E0611
import logging
logger = logging.getLogger('prey')

from prey_lib import Window
from prey.AboutPreyDialog import AboutPreyDialog
from prey.PreferencesPreyDialog import PreferencesPreyDialog

# See prey_lib.Window.py for more details about how this class works
class PreyWindow(Window):
    __gtype_name__ = "PreyWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(PreyWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutPreyDialog
        self.PreferencesDialog = PreferencesPreyDialog

        # Code for other initialization actions should be added here.

        self.preybutton = self.builder.get_object('preybutton')
        self.exitbutton = self.builder.get_object('exitbutton')
        self.refreshbutton = self.builder.get_object('refreshbutton')

        username = getpass.getuser()
        username = str(username)

    def on_refreshbutton_clicked(self, widget):
        os.system('clear')
        os.system('sensible-browser --private-window="https://panel.preyproject.com/login"')
        os.system('clear')

    def on_exitbutton_clicked(self, widget):
        os.system('clear')
        exit()

    def on_preybutton_clicked(self, widget):
        os.system('clear')
        os.system('killall prey &')
        os.system('sensible-browser --private-window="https://panel.preyproject.com/login" &')
        os.system('clear')


