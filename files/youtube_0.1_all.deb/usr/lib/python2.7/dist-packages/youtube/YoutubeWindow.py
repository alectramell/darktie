# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2015 Alec Tramell, DMA alectramell@gmail.com
# 
# All licensing for this app belongs to Google Inc.
# http://www.google.com
# 
# Any development questions can be queried via..
# http://apollondatametrics.zohosites.com/contact.html
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import os

from locale import gettext as _

from gi.repository import Gtk, WebKit # pylint: disable=E0611
import logging
logger = logging.getLogger('youtube')

from youtube_lib import Window
from youtube.AboutYoutubeDialog import AboutYoutubeDialog
from youtube.PreferencesYoutubeDialog import PreferencesYoutubeDialog

# See youtube_lib.Window.py for more details about how this class works
class YoutubeWindow(Window):
    __gtype_name__ = "YoutubeWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(YoutubeWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutYoutubeDialog
        self.PreferencesDialog = PreferencesYoutubeDialog

        # Code for other initialization actions should be added here.

        self.homebutton = self.builder.get_object('homebutton')
        self.exitbutton = self.builder.get_object('exitbutton')
        self.scrolledwindow1 = self.builder.get_object('scrolledwindow1')

        self.webview = WebKit.WebView()

        self.scrolledwindow1.add(self.webview)
        self.webview.show()

        home = str('http://www.youtube.com')
        self.webview.open(home)

    def on_homebutton_clicked(self, widget):
        url = str('http://www.youtube.com')
        self.webview.open(url)

    def on_exitbutton_clicked(self, widget):
        exit()






