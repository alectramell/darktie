# -*- Mode: Python; coding: utf-8; indent-tabs-mode: nil; tab-width: 4 -*-
### BEGIN LICENSE
# Copyright (C) 2014 Alec Tramell, DMA alectramell@gmail.com
# This program is free software: you can redistribute it and/or modify it 
# under the terms of the GNU General Public License version 3, as published 
# by the Free Software Foundation.
# 
# This program is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranties of 
# MERCHANTABILITY, SATISFACTORY QUALITY, or FITNESS FOR A PARTICULAR 
# PURPOSE.  See the GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License along 
# with this program.  If not, see <http://www.gnu.org/licenses/>.
### END LICENSE

import os
import getpass

from locale import gettext as _

from gi.repository import Gtk # pylint: disable=E0611
import logging
logger = logging.getLogger('colors')

from colors_lib import Window
from colors.AboutColorsDialog import AboutColorsDialog
from colors.PreferencesColorsDialog import PreferencesColorsDialog

# See colors_lib.Window.py for more details about how this class works
class ColorsWindow(Window):
    __gtype_name__ = "ColorsWindow"
    
    def finish_initializing(self, builder): # pylint: disable=E1002
        """Set up the main window"""
        super(ColorsWindow, self).finish_initializing(builder)

        self.AboutDialog = AboutColorsDialog
        self.PreferencesDialog = PreferencesColorsDialog

        # Code for other initialization actions should be added here.

        self.label1 = self.builder.get_object('label1')
        self.colorbutton = self.builder.get_object('colorbutton')
        self.exitbutton = self.builder.get_object('exitbutton')

        self.user = str(getpass.getuser())

    def on_colorbutton_clicked(self, widget):
        os.system('touch ~/Desktop/color.txt && COLOR=$(zenity --color-selection --title="COLORS!") && echo "$COLOR" > ~/Desktop/color.txt')
        color = open('/home/' + self.user + '/Desktop/color.txt','r')
        self.code = color.read()
        color.close()
        self.label1.set_label(self.code)

    def on_exitbutton_clicked(self, widget):
        os.system('clear')
        exit()








