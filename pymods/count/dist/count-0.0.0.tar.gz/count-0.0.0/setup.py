#!/usr/bin/python

from distutils.core import setup

setup(name='count',
      py_modules='count',)
